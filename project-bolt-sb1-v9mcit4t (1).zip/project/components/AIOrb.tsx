import React, { useEffect } from 'react';
import { StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  withDelay,
  Easing,
  interpolate,
} from 'react-native-reanimated';
import { Colors, AssistantStatus } from '@/lib/theme';

interface AIOrbProps {
  status: AssistantStatus;
  size?: number;
}

const orbColorMap: Record<AssistantStatus, string> = {
  idle: Colors.orbIdle,
  ready: Colors.orbIdle,
  listening: Colors.orbListening,
  thinking: Colors.orbThinking,
  speaking: Colors.orbSpeaking,
};

export function AIOrb({ status, size = 200 }: AIOrbProps) {
  const breathScale = useSharedValue(1);
  const pulseScale = useSharedValue(1);
  const ringScale = useSharedValue(1);
  const ringOpacity = useSharedValue(0.6);

  useEffect(() => {
    const isActive = status === 'listening' || status === 'speaking';
    const speed = status === 'thinking' ? 700 : isActive ? 900 : 2000;

    breathScale.value = withRepeat(
      withSequence(
        withTiming(1.08, { duration: speed, easing: Easing.inOut(Easing.ease) }),
        withTiming(0.95, { duration: speed, easing: Easing.inOut(Easing.ease) })
      ),
      -1,
      true
    );

    pulseScale.value = withRepeat(
      withSequence(
        withTiming(1.15, { duration: speed * 1.5, easing: Easing.out(Easing.ease) }),
        withTiming(1, { duration: speed * 1.5, easing: Easing.inOut(Easing.ease) })
      ),
      -1,
      true
    );

    ringScale.value = withRepeat(
      withSequence(
        withDelay(400, withTiming(1.6, { duration: 2000, easing: Easing.out(Easing.ease) })),
        withTiming(1, { duration: 0 })
      ),
      -1,
      false
    );

    ringOpacity.value = withRepeat(
      withSequence(
        withDelay(400, withTiming(0, { duration: 2000, easing: Easing.out(Easing.ease) })),
        withTiming(0.5, { duration: 0 })
      ),
      -1,
      false
    );
  }, [status, breathScale, pulseScale, ringScale, ringOpacity]);

  const orbColor = orbColorMap[status];
  const glowSize = size * 1.4;

  const coreStyle = useAnimatedStyle(() => ({
    transform: [{ scale: breathScale.value }],
  }));

  const innerGlowStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulseScale.value }],
    opacity: interpolate(pulseScale.value, [1, 1.15], [0.6, 0.3]),
  }));

  const ringStyle = useAnimatedStyle(() => ({
    transform: [{ scale: ringScale.value }],
    opacity: ringOpacity.value,
  }));

  const ringStyle2 = useAnimatedStyle(() => ({
    transform: [{ scale: ringScale.value * 0.85 }],
    opacity: interpolate(ringOpacity.value, [0, 0.5], [0, 0.3]),
  }));

  return (
    <Animated.View style={[styles.container, { width: glowSize, height: glowSize }]}>
      <Animated.View
        style={[
          styles.ring,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            borderColor: orbColor,
          },
          ringStyle,
        ]}
      />
      <Animated.View
        style={[
          styles.ring,
          {
            width: size * 0.9,
            height: size * 0.9,
            borderRadius: (size * 0.9) / 2,
            borderColor: orbColor,
          },
          ringStyle2,
        ]}
      />
      <Animated.View
        style={[
          styles.outerGlow,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            backgroundColor: orbColor,
          },
        ]}
      />
      <Animated.View
        style={[
          styles.innerGlow,
          {
            width: size * 0.7,
            height: size * 0.7,
            borderRadius: (size * 0.7) / 2,
            backgroundColor: orbColor,
          },
          innerGlowStyle,
        ]}
      />
      <Animated.View
        style={[
          styles.core,
          {
            width: size * 0.55,
            height: size * 0.55,
            borderRadius: (size * 0.55) / 2,
          },
          coreStyle,
        ]}
      >
        <Animated.View
          style={[
            styles.coreHighlight,
            {
              borderRadius: (size * 0.55) / 2,
            },
          ]}
        />
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  ring: {
    position: 'absolute',
    borderWidth: 1.5,
  },
  outerGlow: {
    position: 'absolute',
    opacity: 0.12,
  },
  innerGlow: {
    position: 'absolute',
    opacity: 0.25,
  },
  core: {
    backgroundColor: '#0A0B14',
    borderWidth: 1,
    borderColor: 'rgba(74, 124, 255, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#4A7CFF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 30,
    elevation: 10,
  },
  coreHighlight: {
    position: 'absolute',
    top: '12%',
    left: '18%',
    width: '35%',
    height: '25%',
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
  },
});
