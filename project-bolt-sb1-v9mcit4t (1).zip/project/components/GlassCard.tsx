import React from 'react';
import { StyleSheet, View, ViewStyle } from 'react-native';
import { Colors, BorderRadius } from '@/lib/theme';

interface GlassCardProps {
  children: React.ReactNode;
  style?: ViewStyle | ViewStyle[];
  glowColor?: string;
  glowIntensity?: number;
}

export function GlassCard({
  children,
  style,
  glowColor = Colors.primary,
  glowIntensity = 0.06,
}: GlassCardProps) {
  return (
    <View style={[styles.wrapper, style]}>
      <View
        style={[
          styles.glow,
          {
            backgroundColor: glowColor,
            opacity: glowIntensity,
          },
        ]}
      />
      <View style={styles.card}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'relative',
    borderRadius: BorderRadius.lg,
  },
  glow: {
    position: 'absolute',
    top: -1,
    left: -1,
    right: -1,
    bottom: -1,
    borderRadius: BorderRadius.lg + 1,
  },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
  },
});
