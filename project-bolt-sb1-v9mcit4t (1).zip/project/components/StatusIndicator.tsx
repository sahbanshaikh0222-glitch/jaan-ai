import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { Colors, Fonts, FontSizes, AssistantStatus, statusLabels } from '@/lib/theme';

interface StatusIndicatorProps {
  status: AssistantStatus;
}

const statusColorMap: Record<AssistantStatus, string> = {
  idle: Colors.textSecondary,
  ready: Colors.textSecondary,
  listening: Colors.accent,
  thinking: Colors.secondary,
  speaking: Colors.primary,
};

export function StatusIndicator({ status }: StatusIndicatorProps) {
  const dotScale = useSharedValue(1);
  const isActive = status === 'listening' || status === 'thinking' || status === 'speaking';

  React.useEffect(() => {
    if (isActive) {
      dotScale.value = withRepeat(
        withTiming(1.4, { duration: 600, easing: Easing.inOut(Easing.ease) }),
        -1,
        true
      );
    } else {
      dotScale.value = 1;
    }
  }, [isActive, dotScale]);

  const dotStyle = useAnimatedStyle(() => ({
    transform: [{ scale: dotScale.value }],
  }));

  const color = statusColorMap[status];

  return (
    <View style={styles.container}>
      <Animated.View
        style={[
          styles.dot,
          { backgroundColor: color, shadowColor: color },
          dotStyle,
        ]}
      />
      <Text style={[styles.label, { color: Colors.text }]}>{statusLabels[status]}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 6,
    elevation: 3,
  },
  label: {
    fontFamily: Fonts.medium,
    fontSize: FontSizes.body,
    letterSpacing: 0.5,
  },
});
