import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Colors, Fonts, FontSizes, BorderRadius } from '@/lib/theme';

interface ProfileAvatarProps {
  name?: string;
  size?: number;
}

export function ProfileAvatar({ name = 'Jaan', size = 40 }: ProfileAvatarProps) {
  const initials = name.charAt(0).toUpperCase();

  return (
    <View
      style={[
        styles.container,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
        },
      ]}
    >
      <View style={styles.inner}>
        <Text style={[styles.initials, { fontSize: size * 0.4 }]}>{initials}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'rgba(74, 124, 255, 0.15)',
    borderWidth: 1.5,
    borderColor: 'rgba(74, 124, 255, 0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inner: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  initials: {
    fontFamily: Fonts.bold,
    color: Colors.primaryGlow,
  },
});
