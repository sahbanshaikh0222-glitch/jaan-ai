import React from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity } from 'react-native';
import { Mic, Send, X } from 'lucide-react-native';
import { Colors, Fonts, FontSizes, BorderRadius, AssistantStatus } from '@/lib/theme';

interface ChatInputProps {
  value: string;
  onChangeText: (text: string) => void;
  onSend: () => void;
  onMicPress: () => void;
  isListening: boolean;
  status: AssistantStatus;
}

export function ChatInput({
  value,
  onChangeText,
  onSend,
  onMicPress,
  isListening,
  status,
}: ChatInputProps) {
  const canSend = value.trim().length > 0 && status !== 'thinking';

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={[
          styles.micButton,
          isListening && styles.micButtonActive,
        ]}
        onPress={onMicPress}
        activeOpacity={0.7}
      >
        {isListening ? (
          <X size={22} color={Colors.error} strokeWidth={2.5} />
        ) : (
          <Mic size={22} color={Colors.primary} strokeWidth={2} />
        )}
      </TouchableOpacity>

      <View style={styles.inputWrapper}>
        {isListening ? (
          <View style={styles.listeningContainer}>
            <View style={styles.waveform}>
              {[0, 1, 2, 3, 4].map((i) => (
                <View
                  key={i}
                  style={[
                    styles.waveBar,
                    {
                      height: 8 + Math.abs(Math.sin(Date.now() / 200 + i * 0.8)) * 20,
                      backgroundColor: Colors.accent,
                    },
                  ]}
                />
              ))}
            </View>
            <Text style={styles.listeningText}>Listening...</Text>
          </View>
        ) : (
          <TextInput
            style={styles.input}
            value={value}
            onChangeText={onChangeText}
            placeholder="Batao jaan, kya karna hai?"
            placeholderTextColor={Colors.textMuted}
            onSubmitEditing={canSend ? onSend : undefined}
            returnKeyType="send"
          />
        )}
      </View>

      <TouchableOpacity
        style={[
          styles.sendButton,
          canSend ? styles.sendButtonActive : styles.sendButtonInactive,
        ]}
        onPress={onSend}
        disabled={!canSend}
        activeOpacity={0.7}
      >
        <Send
          size={20}
          color={canSend ? '#FFFFFF' : Colors.textMuted}
          strokeWidth={2}
        />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  micButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(20, 22, 38, 0.8)',
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  micButtonActive: {
    borderColor: Colors.error,
    backgroundColor: 'rgba(255, 92, 122, 0.1)',
  },
  inputWrapper: {
    flex: 1,
    minHeight: 48,
    borderRadius: BorderRadius.lg,
    backgroundColor: 'rgba(20, 22, 38, 0.8)',
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: 16,
    justifyContent: 'center',
  },
  input: {
    fontFamily: Fonts.regular,
    fontSize: FontSizes.body,
    color: Colors.text,
    paddingVertical: 12,
  },
  listeningContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 10,
  },
  waveform: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    height: 28,
  },
  waveBar: {
    width: 3,
    borderRadius: 2,
  },
  listeningText: {
    fontFamily: Fonts.medium,
    fontSize: FontSizes.caption,
    color: Colors.accent,
  },
  sendButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonActive: {
    backgroundColor: Colors.primary,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 5,
  },
  sendButtonInactive: {
    backgroundColor: 'rgba(20, 22, 38, 0.8)',
    borderWidth: 1,
    borderColor: Colors.border,
  },
});
