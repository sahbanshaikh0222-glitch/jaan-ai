import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import {
  Settings as SettingsIcon,
  Volume2,
  Vibrate,
  Moon,
  Heart,
  Info,
  ChevronRight,
  Trash2,
} from 'lucide-react-native';
import { Colors, Fonts, FontSizes } from '@/lib/theme';
import { GlassCard } from '@/components/GlassCard';
import { ProfileAvatar } from '@/components/ProfileAvatar';
import { supabase } from '@/lib/supabase';

const memStore: Record<string, string> = {};
const storage = {
  getItem: async (key: string): Promise<string | null> => memStore[key] ?? null,
  setItem: async (key: string, value: string): Promise<void> => {
    memStore[key] = value;
  },
};

export default function SettingsScreen() {
  const router = useRouter();
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [hapticsEnabled, setHapticsEnabled] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [autoListen, setAutoListen] = useState(false);
  const [assistantName, setAssistantName] = useState('Jaan AI');
  const [messageCount, setMessageCount] = useState(0);

  useEffect(() => {
    (async () => {
      const v = await storage!.getItem('voiceEnabled');
      const h = await storage!.getItem('hapticsEnabled');
      const a = await storage!.getItem('autoListen');
      if (v !== null) setVoiceEnabled(v === 'true');
      if (h !== null) setHapticsEnabled(h === 'true');
      if (a !== null) setAutoListen(a === 'true');

      try {
        const { count } = await supabase
          .from('messages')
          .select('*', { count: 'exact', head: true });
        setMessageCount(count || 0);
      } catch {}
    })();
  }, []);

  const toggleVoice = async (val: boolean) => {
    setVoiceEnabled(val);
    await storage!.setItem('voiceEnabled', String(val));
  };

  const toggleHaptics = async (val: boolean) => {
    setHapticsEnabled(val);
    await storage!.setItem('hapticsEnabled', String(val));
  };

  const toggleAutoListen = async (val: boolean) => {
    setAutoListen(val);
    await storage!.setItem('autoListen', String(val));
  };

  const handleClearData = () => {
    Alert.alert(
      'Saari memory delete karein?',
      'Jaan AI ke saath ki saari baatein permanently delete ho jayengi. Yeh wapas nahi aayengi.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: async () => {
            await supabase.from('conversations').delete().neq('id', '00000000-0000-0000-0000-000000000000');
            setMessageCount(0);
            Alert.alert('Done!', 'Saari memory delete ho gayi.');
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerIcon}>
          <SettingsIcon size={26} color={Colors.primary} strokeWidth={2} />
        </View>
        <Text style={styles.title}>Settings</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>PROFILE</Text>
          <GlassCard style={styles.sectionCard}>
            <View style={styles.profileRow}>
              <ProfileAvatar name="Jaan" size={52} />
              <View style={styles.profileInfo}>
                <Text style={styles.profileName}>{assistantName}</Text>
                <Text style={styles.profileMeta}>{messageCount} messages exchanged</Text>
              </View>
              <Heart size={20} color={Colors.error} strokeWidth={2} />
            </View>
          </GlassCard>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionLabel}>PREFERENCES</Text>
          <GlassCard style={styles.sectionCard}>
            <SettingRow
              icon={<Volume2 size={20} color={Colors.accent} strokeWidth={2} />}
              label="Voice Responses"
              subtitle="Jaan AI bolke jawab de"
            >
              <Switch
                value={voiceEnabled}
                onValueChange={toggleVoice}
                trackColor={{ false: Colors.border, true: Colors.primary }}
                thumbColor={voiceEnabled ? '#FFFFFF' : Colors.textMuted}
              />
            </SettingRow>

            <Divider />

            <SettingRow
              icon={<Vibrate size={20} color={Colors.secondary} strokeWidth={2} />}
              label="Haptic Feedback"
              subtitle="Touch vibration on interactions"
            >
              <Switch
                value={hapticsEnabled}
                onValueChange={toggleHaptics}
                trackColor={{ false: Colors.border, true: Colors.secondary }}
                thumbColor={hapticsEnabled ? '#FFFFFF' : Colors.textMuted}
              />
            </SettingRow>

            <Divider />

            <SettingRow
              icon={<Moon size={20} color={Colors.primaryGlow} strokeWidth={2} />}
              label="Dark Mode"
              subtitle="Always on for this version"
            >
              <Switch
                value={darkMode}
                onValueChange={() => {}}
                disabled
                trackColor={{ false: Colors.border, true: Colors.primary }}
                thumbColor="#FFFFFF"
              />
            </SettingRow>

            <Divider />

            <SettingRow
              icon={<Volume2 size={20} color={Colors.success} strokeWidth={2} />}
              label="Auto-Listen"
              subtitle="Mic auto-start after reply"
            >
              <Switch
                value={autoListen}
                onValueChange={toggleAutoListen}
                trackColor={{ false: Colors.border, true: Colors.success }}
                thumbColor={autoListen ? '#FFFFFF' : Colors.textMuted}
              />
            </SettingRow>
          </GlassCard>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionLabel}>DATA</Text>
          <GlassCard style={styles.sectionCard}>
            <TouchableOpacity
              style={styles.dangerRow}
              onPress={handleClearData}
              activeOpacity={0.7}
            >
              <View style={styles.dangerIcon}>
                <Trash2 size={20} color={Colors.error} strokeWidth={2} />
              </View>
              <View style={styles.dangerInfo}>
                <Text style={styles.dangerText}>Clear All Memory</Text>
                <Text style={styles.dangerSubtitle}>
                  Saari conversations delete karein
                </Text>
              </View>
              <ChevronRight size={18} color={Colors.textMuted} strokeWidth={2} />
            </TouchableOpacity>
          </GlassCard>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionLabel}>ABOUT</Text>
          <GlassCard style={styles.sectionCard}>
            <SettingRow
              icon={<Info size={20} color={Colors.textSecondary} strokeWidth={2} />}
              label="Jaan AI"
              subtitle="Version 1.0.0"
            >
              <Text style={styles.versionBadge}>v1.0</Text>
            </SettingRow>
          </GlassCard>
        </View>

        <Text style={styles.footerText}>
          Made with ❤️ for jaan
        </Text>
      </View>
    </View>
  );
}

function SettingRow({
  icon,
  label,
  subtitle,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  subtitle?: string;
  children?: React.ReactNode;
}) {
  return (
    <View style={styles.settingRow}>
      <View style={styles.settingIcon}>{icon}</View>
      <View style={styles.settingInfo}>
        <Text style={styles.settingLabel}>{label}</Text>
        {subtitle && <Text style={styles.settingSubtitle}>{subtitle}</Text>}
      </View>
      {children}
    </View>
  );
}

function Divider() {
  return <View style={styles.divider} />;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    alignItems: 'center',
    paddingTop: 70,
    paddingBottom: 20,
  },
  headerIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(74, 124, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(74, 124, 255, 0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  title: {
    fontFamily: Fonts.bold,
    fontSize: FontSizes.largeTitle,
    color: Colors.text,
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
    paddingBottom: 32,
  },
  section: {
    marginBottom: 24,
  },
  sectionLabel: {
    fontFamily: Fonts.medium,
    fontSize: 11,
    color: Colors.textMuted,
    letterSpacing: 1.5,
    marginBottom: 10,
    marginLeft: 4,
  },
  sectionCard: {
    paddingHorizontal: 16,
    paddingVertical: 4,
  },
  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    gap: 14,
  },
  profileInfo: {
    flex: 1,
    gap: 2,
  },
  profileName: {
    fontFamily: Fonts.bold,
    fontSize: FontSizes.bodyLarge,
    color: Colors.text,
  },
  profileMeta: {
    fontFamily: Fonts.regular,
    fontSize: FontSizes.caption,
    color: Colors.textSecondary,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    gap: 14,
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(20, 22, 38, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  settingInfo: {
    flex: 1,
    gap: 2,
  },
  settingLabel: {
    fontFamily: Fonts.medium,
    fontSize: FontSizes.body,
    color: Colors.text,
  },
  settingSubtitle: {
    fontFamily: Fonts.regular,
    fontSize: FontSizes.caption,
    color: Colors.textSecondary,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: 2,
  },
  dangerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    gap: 14,
  },
  dangerIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 92, 122, 0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  dangerInfo: {
    flex: 1,
    gap: 2,
  },
  dangerText: {
    fontFamily: Fonts.medium,
    fontSize: FontSizes.body,
    color: Colors.error,
  },
  dangerSubtitle: {
    fontFamily: Fonts.regular,
    fontSize: FontSizes.caption,
    color: Colors.textSecondary,
  },
  versionBadge: {
    fontFamily: Fonts.medium,
    fontSize: FontSizes.caption,
    color: Colors.textMuted,
    backgroundColor: 'rgba(20, 22, 38, 0.6)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    overflow: 'hidden',
  },
  footerText: {
    fontFamily: Fonts.regular,
    fontSize: FontSizes.caption,
    color: Colors.textMuted,
    textAlign: 'center',
    marginTop: 8,
  },
});
