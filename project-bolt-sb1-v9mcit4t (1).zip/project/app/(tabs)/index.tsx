import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Animated,
  TouchableOpacity,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Settings, Brain } from 'lucide-react-native';
import { supabase, Conversation, Message } from '@/lib/supabase';
import { generateResponse, generateGreeting, generateTitle } from '@/lib/assistantEngine';
import { Colors, Fonts, FontSizes, AssistantStatus } from '@/lib/theme';
import { AIOrb } from '@/components/AIOrb';
import { StatusIndicator } from '@/components/StatusIndicator';
import { ChatBubble } from '@/components/ChatBubble';
import { ChatInput } from '@/components/ChatInput';
import { ProfileAvatar } from '@/components/ProfileAvatar';
import { GlassCard } from '@/components/GlassCard';

interface DisplayMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
}

export default function AssistantScreen() {
  const router = useRouter();
  const [messages, setMessages] = useState<DisplayMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [status, setStatus] = useState<AssistantStatus>('idle');
  const [isListening, setIsListening] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const flatListRef = useRef<FlatList>(null);

  useEffect(() => {
    loadOrCreateConversation();
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();
  }, []);

  const loadOrCreateConversation = useCallback(async () => {
    try {
      const { data: existing } = await supabase
        .from('conversations')
        .select('id, title')
        .order('updated_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (existing) {
        setConversationId(existing.id);
        const { data: msgs } = await supabase
          .from('messages')
          .select('*')
          .eq('conversation_id', existing.id)
          .order('created_at', { ascending: true });

        if (msgs && msgs.length > 0) {
          setMessages(msgs as DisplayMessage[]);
        } else {
          const greeting = generateGreeting();
          const { data: savedGreeting } = await supabase
            .from('messages')
            .insert({
              conversation_id: existing.id,
              role: 'assistant',
              content: greeting,
            })
            .select()
            .single();
          if (savedGreeting) {
            setMessages([savedGreeting as DisplayMessage]);
          }
        }
      } else {
        const { data: newConv, error } = await supabase
          .from('conversations')
          .insert({ title: 'New Conversation' })
          .select()
          .single();

        if (error || !newConv) return;

        setConversationId(newConv.id);
        const greeting = generateGreeting();
        const { data: savedGreeting } = await supabase
          .from('messages')
          .insert({
            conversation_id: newConv.id,
            role: 'assistant',
            content: greeting,
          })
          .select()
          .single();

        if (savedGreeting) {
          setMessages([savedGreeting as DisplayMessage]);
        }
      }
    } catch (err) {
      const greeting = generateGreeting();
      setMessages([{
        id: 'temp-greeting',
        role: 'assistant',
        content: greeting,
        created_at: new Date().toISOString(),
      }]);
    }
  }, []);

  const scrollToBottom = useCallback(() => {
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  }, []);

  const handleSend = useCallback(async () => {
    const text = inputText.trim();
    if (!text || status === 'thinking') return;

    setInputText('');
    setStatus('thinking');

    const userMsg: DisplayMessage = {
      id: `temp-user-${Date.now()}`,
      role: 'user',
      content: text,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);
    scrollToBottom();

    let convId = conversationId;
    if (!convId) return;

    try {
      await supabase.from('messages').insert({
        conversation_id: convId,
        role: 'user',
        content: text,
      });

      if (messages.length <= 1) {
        const title = generateTitle(text);
        await supabase
          .from('conversations')
          .update({ title, updated_at: new Date().toISOString() })
          .eq('id', convId);
      }

      const history: { role: 'user' | 'assistant'; content: string }[] = messages.map(m => ({
        role: m.role,
        content: m.content,
      }));

      const response = await generateResponse(text, history, convId);

      let assistantMsg: DisplayMessage;

      if (response.includes('__EDGE_SAVED__')) {
        const { data: lastMsg } = await supabase
          .from('messages')
          .select('*')
          .eq('conversation_id', convId)
          .order('created_at', { ascending: false })
          .limit(1)
          .single();
        assistantMsg = lastMsg
          ? (lastMsg as DisplayMessage)
          : {
              id: `temp-assistant-${Date.now()}`,
              role: 'assistant',
              content: response.replace('__EDGE_SAVED__', ''),
              created_at: new Date().toISOString(),
            };
      } else {
        const { data: savedResponse } = await supabase
          .from('messages')
          .insert({
            conversation_id: convId,
            role: 'assistant',
            content: response,
          })
          .select()
          .single();

        assistantMsg = savedResponse
          ? (savedResponse as DisplayMessage)
          : {
              id: `temp-assistant-${Date.now()}`,
              role: 'assistant',
              content: response,
              created_at: new Date().toISOString(),
            };
      }

      setStatus('speaking');
      setMessages((prev) => [...prev, assistantMsg]);
      scrollToBottom();

      await supabase
        .from('conversations')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', convId);

      setTimeout(() => {
        setStatus((prev) => (prev === 'speaking' ? 'idle' : prev));
      }, 1200);
    } catch (err) {
      const errorMsg: DisplayMessage = {
        id: `temp-error-${Date.now()}`,
        role: 'assistant',
        content: 'Sorry jaan, thodi problem aa gayi. Phir se try karo?',
        created_at: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, errorMsg]);
      setStatus('idle');
    }
  }, [inputText, status, conversationId, messages.length, scrollToBottom]);

  const handleMicPress = useCallback(() => {
    if (isListening) {
      setIsListening(false);
      setStatus('idle');
    } else {
      setIsListening(true);
      setStatus('listening');
      setTimeout(() => {
        setIsListening(false);
        setStatus('idle');
      }, 5000);
    }
  }, [isListening]);

  const renderMessage = useCallback(({ item }: { item: DisplayMessage }) => (
    <ChatBubble role={item.role} content={item.content} />
  ), []);

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <ProfileAvatar name="Jaan" size={40} />
          <View style={styles.headerInfo}>
            <Text style={styles.headerTitle}>Jaan AI</Text>
            <Text style={styles.headerSubtitle}>Your personal companion</Text>
          </View>
        </View>
        <View style={styles.headerRight}>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => router.push('/(tabs)/memory')}
            activeOpacity={0.7}
          >
            <Brain size={22} color={Colors.secondary} strokeWidth={2} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => router.push('/(tabs)/settings')}
            activeOpacity={0.7}
          >
            <Settings size={22} color={Colors.textSecondary} strokeWidth={2} />
          </TouchableOpacity>
        </View>
      </View>

      <Animated.View style={[styles.orbSection, { opacity: fadeAnim }]}>
        <AIOrb status={status} size={170} />
        <View style={styles.statusWrapper}>
          <StatusIndicator status={status} />
        </View>
      </Animated.View>

      <View style={styles.chatSection}>
        {messages.length > 0 ? (
          <FlatList
            ref={flatListRef}
            data={messages}
            renderItem={renderMessage}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.chatList}
            showsVerticalScrollIndicator={false}
            onContentSizeChange={scrollToBottom}
          />
        ) : (
          <View style={styles.emptyChat}>
            <Text style={styles.emptyText}>Batao jaan, kya karna hai?</Text>
          </View>
        )}
      </View>

      <View style={styles.inputSection}>
        <ChatInput
          value={inputText}
          onChangeText={setInputText}
          onSend={handleSend}
          onMicPress={handleMicPress}
          isListening={isListening}
          status={status}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 60,
    paddingBottom: 8,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerInfo: {
    gap: 2,
  },
  headerTitle: {
    fontFamily: Fonts.bold,
    fontSize: FontSizes.bodyLarge,
    color: Colors.text,
  },
  headerSubtitle: {
    fontFamily: Fonts.regular,
    fontSize: FontSizes.caption,
    color: Colors.textMuted,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(20, 22, 38, 0.6)',
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  orbSection: {
    alignItems: 'center',
    paddingVertical: 16,
  },
  statusWrapper: {
    marginTop: 12,
  },
  chatSection: {
    flex: 1,
  },
  chatList: {
    paddingVertical: 8,
  },
  emptyChat: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontFamily: Fonts.medium,
    fontSize: FontSizes.body,
    color: Colors.textMuted,
  },
  inputSection: {
    paddingBottom: 24,
  },
});
