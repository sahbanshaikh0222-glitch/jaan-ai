import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Brain, Trash2, MessageCircle, ChevronRight } from 'lucide-react-native';
import { supabase, Conversation } from '@/lib/supabase';
import { Colors, Fonts, FontSizes, BorderRadius, Spacing } from '@/lib/theme';
import { GlassCard } from '@/components/GlassCard';

interface ConversationWithMeta extends Conversation {
  message_count?: number;
  last_message?: string;
}

export default function MemoryScreen() {
  const router = useRouter();
  const [conversations, setConversations] = useState<ConversationWithMeta[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadConversations = useCallback(async () => {
    try {
      const { data: convs, error } = await supabase
        .from('conversations')
        .select('*')
        .order('updated_at', { ascending: false });

      if (error) throw error;
      if (!convs) {
        setConversations([]);
        return;
      }

      const enriched = await Promise.all(
        convs.map(async (conv) => {
          const { data: lastMsg } = await supabase
            .from('messages')
            .select('content')
            .eq('conversation_id', conv.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          const { count } = await supabase
            .from('messages')
            .select('*', { count: 'exact', head: true })
            .eq('conversation_id', conv.id);

          return {
            ...conv,
            message_count: count || 0,
            last_message: lastMsg?.content || 'No messages',
          };
        })
      );

      setConversations(enriched);
    } catch (err) {
      setConversations([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    loadConversations();
  }, [loadConversations]);

  const handleDelete = useCallback(
    (id: string, title: string) => {
      Alert.alert(
        'Delete memory?',
        `"${title}" ki saari baatein delete ho jayengi.`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Delete',
            style: 'destructive',
            onPress: async () => {
              await supabase.from('conversations').delete().eq('id', id);
              loadConversations();
            },
          },
        ]
      );
    },
    [loadConversations]
  );

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = diffMs / (1000 * 60 * 60);
    const diffDays = diffHours / 24;

    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${Math.floor(diffHours)}h ago`;
    if (diffDays < 7) return `${Math.floor(diffDays)}d ago`;
    return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  };

  const renderItem = useCallback(
    ({ item }: { item: ConversationWithMeta }) => (
      <GlassCard
        glowColor={Colors.secondary}
        glowIntensity={0.04}
        style={styles.cardWrapper}
      >
        <TouchableOpacity
          style={styles.card}
          onPress={() => router.push('/(tabs)')}
          activeOpacity={0.7}
        >
          <View style={styles.cardIcon}>
            <MessageCircle size={20} color={Colors.secondary} strokeWidth={2} />
          </View>
          <View style={styles.cardContent}>
            <Text style={styles.cardTitle} numberOfLines={1}>
              {item.title}
            </Text>
            <Text style={styles.cardPreview} numberOfLines={1}>
              {item.last_message}
            </Text>
            <View style={styles.cardMeta}>
              <Text style={styles.cardMetaText}>
                {item.message_count} messages · {formatDate(item.updated_at)}
              </Text>
            </View>
          </View>
          <TouchableOpacity
            style={styles.deleteButton}
            onPress={() => handleDelete(item.id, item.title)}
            activeOpacity={0.6}
          >
            <Trash2 size={18} color={Colors.error} strokeWidth={2} />
          </TouchableOpacity>
        </TouchableOpacity>
      </GlassCard>
    ),
    [router, handleDelete]
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerIcon}>
          <Brain size={26} color={Colors.secondary} strokeWidth={2} />
        </View>
        <Text style={styles.title}>Memory</Text>
        <Text style={styles.subtitle}>Jaan AI ke saath ki saari baatein</Text>
      </View>

      {conversations.length === 0 && !loading ? (
        <View style={styles.emptyState}>
          <Brain size={48} color={Colors.textMuted} strokeWidth={1.5} />
          <Text style={styles.emptyTitle}>Koi memory nahi hai abhi</Text>
          <Text style={styles.emptySubtitle}>
            Jab aap Jaan AI se baat karenge, yahan save hoga
          </Text>
        </View>
      ) : (
        <FlatList
          data={conversations}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              tintColor={Colors.primary}
              colors={[Colors.primary]}
            />
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    alignItems: 'center',
    paddingTop: 70,
    paddingBottom: 24,
    paddingHorizontal: 20,
  },
  headerIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(155, 109, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(155, 109, 255, 0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  title: {
    fontFamily: Fonts.bold,
    fontSize: FontSizes.largeTitle,
    color: Colors.text,
    marginBottom: 4,
  },
  subtitle: {
    fontFamily: Fonts.regular,
    fontSize: FontSizes.body,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 32,
  },
  cardWrapper: {
    marginBottom: 12,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 14,
  },
  cardIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(155, 109, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(155, 109, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardContent: {
    flex: 1,
    gap: 3,
  },
  cardTitle: {
    fontFamily: Fonts.medium,
    fontSize: FontSizes.body,
    color: Colors.text,
  },
  cardPreview: {
    fontFamily: Fonts.regular,
    fontSize: FontSizes.caption,
    color: Colors.textSecondary,
  },
  cardMeta: {
    marginTop: 2,
  },
  cardMetaText: {
    fontFamily: Fonts.regular,
    fontSize: 11,
    color: Colors.textMuted,
  },
  deleteButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255, 92, 122, 0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
    gap: 12,
  },
  emptyTitle: {
    fontFamily: Fonts.medium,
    fontSize: FontSizes.bodyLarge,
    color: Colors.textSecondary,
    marginTop: 8,
  },
  emptySubtitle: {
    fontFamily: Fonts.regular,
    fontSize: FontSizes.body,
    color: Colors.textMuted,
    textAlign: 'center',
  },
});
